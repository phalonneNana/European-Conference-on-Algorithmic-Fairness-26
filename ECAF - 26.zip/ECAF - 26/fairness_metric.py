from single_stage_policy_gradient import *

#### Extract gender
def extract_genders(X, gender_male_idx, gender_female_idx):
    """
    Extract gender labels from one-hot encoded columns.
    
    Parameters:
    - X: NumPy array of shape (N, d), feature matrix.
    - gender_male_idx: Integer, the column index for male gender.
    - gender_female_idx: Integer, the column index for female gender.
    
    Returns:
    - genders: NumPy array of shape (N,), containing 'Male' or 'Female' based on one-hot encoding.
    """
    genders = np.where(X[:, gender_male_idx] == 1, 'Male', 'Female')
    return genders

Gender_Male=0
Gender_Female=1
#genders = extract_genders(X_train, Gender_Female, Gender_Male)

############ EMC///// LOGISTIC
def compute_emc_logistic(X_train, theta, n_sample, batch_size, model,c, posterior_sampling=True, 
                    n_posterior_samples=10, use_selected=False):
    """
    Returns:
        emc: A vector containing the EMC for each individual in the training set.
    """
    n_individuals = X_train.shape[0]
    emc = np.zeros(n_individuals)
    
    for i in range(n_individuals):
        marginal_contrib = 0
        for _ in range(n_sample):
            # Sample a batch of states (individuals) x from X_train
            indices = np.random.choice(X_train.shape[0], batch_size, replace=False)
            X_batch = X_train[indices] 
            
            # Calculate policy probabilities for the sampled batch
            policy_probs = logistic_policy( X_batch, theta)
            
            # Sample actions for the batch
            actions = np.random.binomial(1, policy_probs)
            
            # Compute utility for the batch without individual i
            utility_a = expected_utility(actions, X_batch, model, c, posterior_sampling=posterior_sampling,
                                         n_posterior_samples=n_posterior_samples, use_selected = use_selected )

            # Find the index of individual i within the current batch
            if i in indices:  # Only proceed if individual i is part of the batch
                index_in_batch = np.where(indices == i)[0][0]  # Find index of individual i in the batch
                actions_with_i = actions.copy()
                actions_with_i[index_in_batch] = 1  # Mark individual i as selected (in the action vector)
            
                # Compute utility with individual i included in the set
                utility_a_plus_i = expected_utility(actions_with_i, X_batch, model, c, posterior_sampling=posterior_sampling,
                                         n_posterior_samples=n_posterior_samples, use_selected = use_selected)
            
                # Compute the marginal contribution for this individual and action
                marginal_contrib +=  (utility_a_plus_i - utility_a)
        
        # Average over n_samples to get EMC for individual i
        emc[i] = marginal_contrib / n_sample
    
    return emc

def fairness_criteria_logistic(X, EMC, theta, tau, epsilon, batch_size):
    
    # Sample a batch of states x from X
    indices = np.random.choice(X.shape[0], batch_size, replace=False)
    x_sample = X[indices]
    emc_sample = EMC[indices]

    # Compute policy probabilities for sampled x
    policy_probs = logistic_policy( x_sample, theta)
    
    # Extract genders
    genders = extract_genders(x_sample, Gender_Female, Gender_Male)
    
    ################## Demographic Parity
    male_prob = np.mean(policy_probs[genders == 'Male'])
    female_prob = np.mean(policy_probs[genders == 'Female'])
    dif = abs(male_prob - female_prob)
    dem =  dif <= epsilon

    #  satisfaction level (normalized between 0 and 1)
    dem_satisfaction = max(0, (epsilon - dif) / epsilon + 0.000001)

    #penalty
    dem_penalty = max(0, dif  - epsilon)

    ############### Equality of Opportunity
    qualified_mask = emc_sample >= tau
    policy_probs_qualified = policy_probs[qualified_mask]
    genders_qualified = genders[qualified_mask] 

    male_probs_qualified = policy_probs_qualified[genders_qualified == 'Male']
    female_probs_qualified = policy_probs_qualified[genders_qualified == 'Female']

    pi_male_qualified = np.mean(male_probs_qualified) if len(male_probs_qualified) > 0 else 0
    pi_female_qualified = np.mean(female_probs_qualified) if len(female_probs_qualified) > 0 else 0
    
    diff= abs(pi_male_qualified - pi_female_qualified)
    equ = diff <= epsilon
    equ_satisfaction=  max(0, (epsilon - diff) / epsilon+0.000001)                                          
    equ_penalty = max(0, diff  - epsilon)
                                           
        
    
    #  results
    results = { 'demographic_parity_male_prob': male_prob,
                'demographic_parity_female_prob': female_prob,
                'equality_of_opportunity_male_prob': pi_male_qualified,
                'equality_of_opportunity_female_prob': pi_female_qualified}
            
    return dem, equ,dem_penalty,equ_penalty, dem_satisfaction,equ_satisfaction, results

def compute_and_plot_logistic(model, theta, emc_logistic,n_sample, tau,X, batch_sizes, epsilons, c,random_seed=42):
    """
    Compute fairness metrics (Dev_swap and Dev_local) for varying lambdas.
    """
    #np.random.seed(random_seed)
    ut_lo = []
    fairness_penalties_lo = []

    for batch_size, epsilon in zip(batch_sizes, epsilons):
        # Compute utility under current batch_size, epsilon
        X_batch = X[np.random.choice(X.shape[0], batch_size, replace=False)]
        #theta,_ = policy_gradient(X_train, model, c, learning_rate, delta, max_iter, n_sample,batch_size)
        uti_lo = policy_utility_logistic(X_batch, model, c, theta, n_sample, batch_size)
        
        # Compute fairness penalties
        _, _, demographic_parity_penalty_lo,equality_of_opportunity_penalty_lo,_,_,_ = fairness_criteria_logistic(X_batch, 
                                                                                    emc_logistic, theta,  tau, epsilon, batch_size)
          
        # Aggregate fairness penalty
        fairness_penalty_lo = demographic_parity_penalty_lo + equality_of_opportunity_penalty_lo
        ut_lo.append(uti_lo)
        fairness_penalties_lo.append(fairness_penalty_lo)
    
    return  ut_lo,  fairness_penalties_lo


############ EMC///// NN
def compute_emc_nn(X_train, model, c, policy_net, n_sample, batch_size, device,posterior_sampling=True, 
                    n_posterior_samples=10, use_selected=False):
    """
    Returns:
        emc: A vector containing the EMC for each individual
    """
    n_individuals = X_train.shape[0]
    emc = np.zeros(n_individuals)

    for i in range(n_individuals):
        marginal_contrib = 0
        for _ in range(n_sample):
            indices = np.random.choice(n_individuals, batch_size, replace=False)
            X_batch = X_train[indices]

            # Get policy probabilities from the NN
            x_tensor = torch.tensor(X_batch, dtype=torch.float32).to(device)
            with torch.no_grad():
                policy_probs = policy_net(x_tensor).cpu().numpy()  # shape: (batch_size,)

             # Sample actions for the batch
            actions = np.random.binomial(1, policy_probs)
            utility_a = expected_utility(actions, X_batch, model, c, posterior_sampling=posterior_sampling,
                                         n_posterior_samples=n_posterior_samples, use_selected = use_selected)

            # Find the index of individual i within the current batch
            if i in indices:  # Only proceed if individual i is part of the batch
                index_in_batch = np.where(indices == i)[0][0]  # Find index of individual i in the batch
                actions_with_i = actions.copy()
                actions_with_i[index_in_batch] = 1  # Mark individual i as selected

                utility_a_plus_i = expected_utility(actions_with_i, X_batch, model, c, posterior_sampling=posterior_sampling,
                                         n_posterior_samples=n_posterior_samples, use_selected = use_selected)
                marginal_contrib += utility_a_plus_i - utility_a

        emc[i] = marginal_contrib / n_sample

    return emc

def fairness_criteria_nn(X, EMC, policy_net, tau, epsilon, batch_size, device):
    
    # Sample a batch of states x from X
    indices = np.random.choice(X.shape[0], batch_size, replace=False)
    x_sample = X[indices]
    emc_sample = EMC[indices]

    # Compute policy probabilities for sampled x using trained NN
    x_tensor = torch.tensor(x_sample, dtype=torch.float32).to(device)
    with torch.no_grad():
        policy_probs = policy_net(x_tensor).cpu().numpy()  # (batch_size,)

    # Extract genders
    genders = extract_genders(x_sample, Gender_Female, Gender_Male)
    
    ################## Demographic Parity
    male_prob = np.mean(policy_probs[genders == 'Male'])
    female_prob = np.mean(policy_probs[genders == 'Female'])
    dif = abs(male_prob - female_prob)
    dem =  dif <= epsilon

    # Satisfaction level (normalized between 0 and 1)
    dem_satisfaction = max(0, (epsilon - dif) / epsilon + 0.000001)

    # Penalty
    dem_penalty = max(0, dif - epsilon)

    ############### Equality of Opportunity
    qualified_mask = emc_sample >= tau
    policy_probs_qualified = policy_probs[qualified_mask]
    genders_qualified = genders[qualified_mask] 

    male_probs_qualified = policy_probs_qualified[genders_qualified == 'Male']
    female_probs_qualified = policy_probs_qualified[genders_qualified == 'Female']

    pi_male_qualified = np.mean(male_probs_qualified) if len(male_probs_qualified) > 0 else 0
    pi_female_qualified = np.mean(female_probs_qualified) if len(female_probs_qualified) > 0 else 0
    
    diff = abs(pi_male_qualified - pi_female_qualified)
    equ = diff <= epsilon
    equ_satisfaction = max(0, (epsilon - diff) / epsilon + 0.000001)                                          
    equ_penalty = max(0, diff - epsilon)

    # Results
    results = {
        'demographic_parity_male_prob': male_prob,
        'demographic_parity_female_prob': female_prob,
        'equality_of_opportunity_male_prob': pi_male_qualified,
        'equality_of_opportunity_female_prob': pi_female_qualified}
            
    return dem, equ, dem_penalty, equ_penalty, dem_satisfaction, equ_satisfaction, results

def compute_and_plot_nn(model, policy_net,n_sample,emc_nn,tau,X, batch_sizes, epsilons, c,random_seed=42):
    """
    Compute fairness metrics (Dev_swap and Dev_local) for varying lambdas.
    """
    #np.random.seed(random_seed)
    ut_nn = []
    fairness_penalties_nn = []

    for batch_size, epsilon in zip(batch_sizes, epsilons):
        # Compute utility under current batch_size, epsilon
        X_batch = X[np.random.choice(X.shape[0], batch_size, replace=False)]
        #theta,_ = policy_gradient(X_train, model, c, learning_rate, delta, max_iter, n_sample,batch_size)
        #policy_net, average_utilities = policy_gradient_nn(X_train, model, c, learning_rate, delta, max_iter, n_sample, 
                                                                #batch_size, device,hidden_dim=64)
        uti_nn = policy_utility_nn(X_batch, model, c, policy_net,  n_sample, batch_size)
        
        
        _, _, demographic_parity_penalty_nn,equality_of_opportunity_penalty_nn,_,_,_ = fairness_criteria_nn(X_batch , emc_nn, policy_net,tau, 
                                                                                                      epsilon, batch_size,device)
          
        # Aggregate fairness penalty
        fairness_penalty_nn = demographic_parity_penalty_nn + equality_of_opportunity_penalty_nn
        ut_nn.append(uti_nn)
        fairness_penalties_nn.append(fairness_penalty_nn)
    
    return  ut_nn, fairness_penalties_nn



