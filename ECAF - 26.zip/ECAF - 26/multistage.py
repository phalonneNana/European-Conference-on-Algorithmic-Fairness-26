from data_preprocessing import *
from policies import *
from probability_distribution import *
from expected_utilities import *

def apply_mean_gpa_based_admission(y_train, threshold):
    """
    
    Returns:
    - a: Action vector indicating which students were admitted (1 for admit, 0 for reject).
    """
    # Calculate the mean GPA across the three courses
    mean_gpa = np.mean(y_train, axis=1)  # Calculate the mean across the last three columns (courses)
    a = (mean_gpa >= threshold).astype(int)  # Admit if mean GPA is above threshold
    return a

###### Logistic
def multi_stage_policy_logistic(X_initial, y_initial, model, c, learning_rate, max_iter,n_sample, num_stages, threshold,posterior_sampling=False,
                                     n_posterior_samples=10,use_selected=True):
    """
    Multi-stage policy gradient with dynamic updates and separate CTGAN models for 
    simulation and feature distribution modeling.

    Returns:
    - theta: Final policy parameters.
    - utilities: Cumulative utilities per stage.
    - episode_utilities_per_stage: Utilities per iteration within each stage.
    """
    theta = np.random.randn(X_initial.shape[1]) * 0.01
    utilities = []
    episode_utilities_per_stage = []
    applied_X = np.empty((0, X_initial.shape[1]))
    cumulative_X = np.empty((0, X_initial.shape[1]))
    cumulative_y = np.empty((0, y_initial.shape[1]))
    initial_learning_rate = learning_rate  # Store initial learning rate
    decay_factor = 0.1

    #  Initialize both  CTGAN models
    ctgan_simulator = CTGAN(epochs=50)   # Generates synthetic applicants
    ctgan_simulator.fit(X_initial)
    simulate_y = MultiOutputRegressor(BayesianRidge()) 
    simulate_y.fit(X_initial, y_initial) 

    ctgan_model = CTGAN(epochs=50)   # Distribution model for applicants 

    percent_admitted_per_stage = []

    for k in range(num_stages):
        learning_rate = initial_learning_rate / (1 + decay_factor * k)  # Learning rate decay
        stage_utilities = []

        
            #  Use the simulator to generate synthetic applicants
        X_applicants = ctgan_simulator.sample(300)[:, :X_initial.shape[1]]
        y_applicants= simulate_y.predict(X_applicants)
        #y_applicants += np.random.normal(0, 0.05, size=y_applicants.shape)
        y_applicants = np.clip(y_applicants, 0, 1)
        
        #  Compute optimal policy for model P_k
        if k == 0:
            a = apply_mean_gpa_based_admission(y_applicants, threshold)
            admitted_indices = np.where(a == 1)[0]
            cumulative_X= np.vstack([cumulative_X, X_applicants[admitted_indices]])
            cumulative_y= np.vstack([cumulative_y, y_applicants[admitted_indices]])
            applied_X = np.vstack([cumulative_X, X_applicants])  

            percent_admitted = (len(admitted_indices) / len(X_applicants)) * 100
            percent_admitted_per_stage.append(percent_admitted)

            first_stage_utility = np.mean(y_applicants[a == 1]) 
            stage_utilities.append(first_stage_utility)  # Append first-stage utility
            episode_utilities_per_stage.append(stage_utilities)  
            model.add_data(cumulative_X, cumulative_y)# Fit model P(y|x,a) on admitted data for the first time
            ctgan_model.fit(applied_X)
        else:
                
            # Sample new posterior parameters (Thompson sample)
            model.select() # samples one set of parameters from the posterior and fixes them for decision making
            
            for iteration in range(max_iter):
                grad = np.zeros_like(theta)
                average_util = 0

                for _ in range(n_sample):
                    policy = logistic_policy( X_applicants, theta)  # Logistic function
                    a = np.random.binomial(1, policy)  # Sample action for each student
                    X_sample = ctgan_model.sample(300)
                    expected_util = expected_utility(a, X_sample, model, c,posterior_sampling=posterior_sampling,
                                     n_posterior_samples=n_posterior_samples,use_selected=use_selected)
                    average_util += expected_util

                    # Compute gradient contribution
                    for i in range(X_applicants.shape[0]):
                        grad_c = X_applicants[i] * (1 - policy[i]) if a[i] == 1 else -X_applicants[i] * policy[i]
                        grad += (expected_util * grad_c) / n_sample

                grad = np.clip(grad, -0.1, 0.1)
                theta += learning_rate * grad
                average_util /= n_sample
                stage_utilities.append(average_util)

                # Convergence check
                if np.linalg.norm(grad) < 1e-6:
                    print(f"Converged at iteration {iteration + 1}")
                    break 

            #  Admit students and check outcomes
            with torch.no_grad():
                final_probs = logistic_policy(X_applicants, theta)
                final_actions = np.random.binomial(1, final_probs)

            admitted_indices = np.where(final_actions == 1)[0]
            percent_admitted = (len(admitted_indices) / len(X_applicants)) * 100
            percent_admitted_per_stage.append(percent_admitted)

            # Safety check to avoid out-of-bound errors
            applied_X = np.vstack([applied_X, X_applicants])
            valid_indices = admitted_indices[admitted_indices < applied_X.shape[0]]

            if len(valid_indices) > 0:
                cumulative_X = np.vstack([cumulative_X, applied_X[valid_indices]])
                cumulative_y = np.vstack([cumulative_y, y_applicants[valid_indices]])
            #     utilities.append(np.mean(y_applicants[valid_indices]))
            # else:
            #     utilities.append(0.0) 

            # Update the model P(y|x,a) (k > 0, we know it)
            model.add_data(cumulative_X, cumulative_y)
            ctgan_model.fit(applied_X)

            utilities.append(np.mean(y_applicants[valid_indices]))
            episode_utilities_per_stage.append(stage_utilities)

    return theta, utilities, episode_utilities_per_stage, percent_admitted_per_stage



##### NN
def multi_stage_policy_nn(X_initial, y_initial, model, learning_rate, c, max_iter,n_sample, num_stages,threshold,device, posterior_sampling=False,
                                     n_posterior_samples=10,use_selected=True, hidden_dim=32):
    """
    Multi-stage policy gradient with dynamic updates and neural network policy.

    Returns:
    - policy_net: Final trained policy network.
    - utilities: Cumulative utilities per stage.
    - episode_utilities_per_stage: Utilities per iteration within each stage.
    """

    # Initialize neural policy network
    input_dim = X_initial.shape[1]
    policy_net = PolicyNet(input_dim, hidden_dim).to(device)
    optimizer = torch.optim.Adam(policy_net.parameters(),learning_rate)
    utilities = []
    episode_utilities_per_stage = []
    applied_X = np.empty((0, X_initial.shape[1]))
    cumulative_X = np.empty((0, X_initial.shape[1]))
    cumulative_y = np.empty((0, y_initial.shape[1]))
    initial_learning_rate = learning_rate  # Store initial learning rate
    decay_factor = 0.3

    #  Initialize both  CTGAN models
    ctgan_simulator = CTGAN(epochs=50)   # Generates synthetic applicants
    ctgan_simulator.fit(X_initial)
    simulate_y = MultiOutputRegressor(BayesianRidge()) 
    simulate_y.fit(X_initial, y_initial) 
    percent_admitted_per_stage = []

    ctgan_model = CTGAN(epochs=50)   # Distribution model for applicants
    for k in range(num_stages):
        # Learning rate decay
        for param_group in optimizer.param_groups:
             param_group['lr'] = initial_learning_rate / (1 + decay_factor * k) # Learning rate decay
        stage_utilities = []

            #  Use the simulator to generate synthetic applicants
        X_applicants = ctgan_simulator.sample(300)[:, :X_initial.shape[1]]
        y_applicants= simulate_y.predict(X_applicants)
        y_applicants += np.random.normal(0, 0.1, size=y_applicants.shape)
        y_applicants = np.clip(y_applicants, 0, 1)
         
        #  Compute optimal policy for model P_k
        if k == 0:
            a = apply_mean_gpa_based_admission(y_applicants, threshold)

            # Remove dataa of non-admitted students
            admitted_indices = np.where(a == 1)[0]
            cumulative_X= np.vstack([cumulative_X, X_applicants[admitted_indices]])
            cumulative_y= np.vstack([cumulative_y, y_applicants[admitted_indices]])
            applied_X = np.vstack([cumulative_X, X_applicants])

            percent_admitted = (len(admitted_indices) / len(X_applicants)) * 100
            percent_admitted_per_stage.append(percent_admitted)

            first_stage_utility = np.mean(y_applicants[a == 1]) 
            stage_utilities.append(first_stage_utility)  # Append first-stage utility
            episode_utilities_per_stage.append(stage_utilities) 
            # We only see the y of the people we actually admit! 
            #  
            model.add_data(cumulative_X, cumulative_y)

            # Train initial distributor from all students
            ctgan_model.fit(applied_X)
        else:

            model.select()

            # Train neural policy network using policy gradient
            X_tensor = torch.tensor(X_applicants, dtype=torch.float32).to(device)
                
            # Compute policy using gradient ascent 
            
            for iteration in range(max_iter):
                optimizer.zero_grad()
                probs = policy_net(X_tensor)  # Action probabilities

                # To avoid log(0), clamp probabilities
                probs = probs.clamp(min=1e-6, max=1-1e-6)
                total_loss = 0
                total_util = 0
                for _ in range(n_sample):
                    a = torch.bernoulli(probs).detach().cpu().numpy()

                    # Compute utility
                    X_sample = ctgan_model.sample(300)
                    expected_util = expected_utility(a, X_sample, model, c,posterior_sampling=posterior_sampling,
                                     n_posterior_samples=n_posterior_samples,use_selected=use_selected)
                    total_util += expected_util

                    # Log-probabilities
                    a_tensor = torch.tensor(a, dtype=probs.dtype, device=device)
                    log_probs = a_tensor * torch.log(probs) + (1 - a_tensor) * torch.log(1 - probs)
                    loss = -expected_util * log_probs.mean()
                    total_loss += loss

                # Average over n_sample
                total_loss /= n_sample
                total_util /= n_sample

                total_loss.backward()
                optimizer.step()
                stage_utilities.append(total_util)

                if torch.norm(torch.tensor(total_util)) < 1e-6:
                    print(f"Converged at iteration {iteration + 1}")
                    break


            #  Admit students and check outcomes
            with torch.no_grad():
                final_probs = policy_net(torch.tensor(X_applicants, dtype=torch.float32).to(device)).cpu().numpy()
                final_actions = np.random.binomial(1, final_probs)

            admitted_indices = np.where(final_actions == 1)[0]
            percent_admitted = (len(admitted_indices) / len(X_applicants)) * 100
            percent_admitted_per_stage.append(percent_admitted)

            # Safety check to avoid out-of-bound errors
            applied_X = np.vstack([applied_X, X_applicants])
            valid_indices = admitted_indices[admitted_indices < applied_X.shape[0]]

            if len(valid_indices) > 0:
                cumulative_X = np.vstack([cumulative_X, X_applicants[valid_indices]])
                cumulative_y = np.vstack([cumulative_y, y_applicants[valid_indices]])
            #     utilities.append(np.mean(y_applicants[valid_indices]))
            # else:
            #     utilities.append(0.0) 

            # Update the model P(y|x,a)
            if k >= 1:
                model.add_data(cumulative_X, cumulative_y)
                ctgan_model.fit(applied_X)

            #  final utilities
            utilities.append(np.mean(y_applicants[valid_indices]))
            episode_utilities_per_stage.append(stage_utilities)

    return policy_net, utilities, episode_utilities_per_stage, percent_admitted_per_stage


########## DELAYED POLICY UPDATED

## Logistic
## Logistic

def multi_stage_policy_logistic_delayed(X_initial, y_initial, model, c, learning_rate, max_iter,
                                        n_sample, num_stages, threshold, posterior_sampling=False,
                                        n_posterior_samples=10, use_selected=True, update_every=1):
 
    theta = np.random.randn(X_initial.shape[1]) * 0.01
    delta = 1e-6
    utilities = []
    episode_utilities_per_stage = []
    applied_X = np.empty((0, X_initial.shape[1]))
    cumulative_X = np.empty((0, X_initial.shape[1]))
    cumulative_y = np.empty((0, y_initial.shape[1]))
    initial_learning_rate = learning_rate
    decay_factor = 0.1

    # Simulators
    ctgan_simulator = CTGAN(epochs=50)
    ctgan_simulator.fit(X_initial)
    simulate_y = MultiOutputRegressor(BayesianRidge()) 
    simulate_y.fit(X_initial, y_initial)

    ctgan_model = CTGAN(epochs=50)
    percent_admitted_per_stage = []

    for k in range(num_stages):
        learning_rate = initial_learning_rate / (1 + decay_factor * k)
        stage_utilities = []

        # Generate synthetic applicants
        X_applicants = ctgan_simulator.sample(300)[:, :X_initial.shape[1]]
        y_applicants = simulate_y.predict(X_applicants)
        y_applicants = np.clip(y_applicants, 0, 1)

        if k == 0:
            a = apply_mean_gpa_based_admission(y_applicants, threshold)
            admitted_indices = np.where(a == 1)[0]
            cumulative_X = np.vstack([cumulative_X, X_applicants[admitted_indices]])
            cumulative_y = np.vstack([cumulative_y, y_applicants[admitted_indices]])
            applied_X = np.vstack([cumulative_X, X_applicants])

            percent_admitted_per_stage.append((len(admitted_indices) / len(X_applicants)) * 100)
            stage_utilities.append(np.mean(y_applicants[a == 1]))
            episode_utilities_per_stage.append(stage_utilities)

            model.add_data(cumulative_X, cumulative_y)
            ctgan_model.fit(applied_X)
        else:
            model.select()

            #  Only update policy if it’s the right stage
            if k % update_every == 0:
                for iteration in range(max_iter):
                    grad = np.zeros_like(theta)
                    average_util = 0

                    for _ in range(n_sample):
                        policy = logistic_policy(X_applicants, theta)
                        a = np.random.binomial(1, policy)
                        X_sample = ctgan_model.sample(300)
                        expected_util = expected_utility(a, X_sample, model, c,
                                                         posterior_sampling=posterior_sampling,
                                                         n_posterior_samples=n_posterior_samples,
                                                         use_selected=use_selected)
                        average_util += expected_util

                        for i in range(X_applicants.shape[0]):
                            grad_c = X_applicants[i] * (1 - policy[i]) if a[i] == 1 else -X_applicants[i] * policy[i]
                            grad += (expected_util * grad_c) / n_sample

                    grad = np.clip(grad, -0.1, 0.1)
                    theta += learning_rate * grad
                    average_util /= n_sample
                    stage_utilities.append(average_util)

                    if np.linalg.norm(grad) < delta:
                        print(f"Converged at iteration {iteration + 1}")
                        break

            # Apply current (possibly older) policy
            final_probs = logistic_policy(X_applicants, theta)
            final_actions = np.random.binomial(1, final_probs)

            admitted_indices = np.where(final_actions == 1)[0]
            percent_admitted = (len(admitted_indices) / len(X_applicants)) * 100
            percent_admitted_per_stage.append(percent_admitted)

            applied_X = np.vstack([applied_X, X_applicants])
            valid_indices = admitted_indices[admitted_indices < applied_X.shape[0]]

            if len(valid_indices) > 0:
                cumulative_X = np.vstack([cumulative_X, X_applicants[valid_indices]])
                cumulative_y = np.vstack([cumulative_y, y_applicants[valid_indices]])

            model.add_data(cumulative_X, cumulative_y)
            ctgan_model.fit(applied_X)

            utilities.append(np.mean(y_applicants[valid_indices]) if len(valid_indices) > 0 else 0.0)
            episode_utilities_per_stage.append(stage_utilities)

    return theta, utilities, episode_utilities_per_stage, percent_admitted_per_stage


## NN
### NN

def multi_stage_policy_nn_delayed(X_initial, y_initial, model, learning_rate, c, max_iter,
                                  n_sample, num_stages, threshold, device,
                                  posterior_sampling=False, n_posterior_samples=10,
                                  use_selected=True, hidden_dim=32, update_every=1):
    input_dim = X_initial.shape[1]
    policy_net = PolicyNet(input_dim, hidden_dim).to(device)
    optimizer = torch.optim.Adam(policy_net.parameters(), learning_rate)
    delta = 1e-6

    utilities = []
    episode_utilities_per_stage = []
    applied_X = np.empty((0, X_initial.shape[1]))
    cumulative_X = np.empty((0, X_initial.shape[1]))
    cumulative_y = np.empty((0, y_initial.shape[1]))
    initial_learning_rate = learning_rate
    decay_factor = 0.3
    percent_admitted_per_stage = []

    # CTGAN models
    ctgan_simulator = CTGAN(epochs=50)
    ctgan_simulator.fit(X_initial)
    simulate_y = MultiOutputRegressor(BayesianRidge()) 
    simulate_y.fit(X_initial, y_initial)

    ctgan_model = CTGAN(epochs=50)

    for k in range(num_stages):
        # Decay learning rate
        for param_group in optimizer.param_groups:
            param_group['lr'] = initial_learning_rate / (1 + decay_factor * k)

        stage_utilities = []

        # Simulate new applicants
        X_applicants = ctgan_simulator.sample(300)[:, :X_initial.shape[1]]
        y_applicants = simulate_y.predict(X_applicants)
        y_applicants += np.random.normal(0, 0.1, size=y_applicants.shape)
        y_applicants = np.clip(y_applicants, 0, 1)

        if k == 0:
            a = apply_mean_gpa_based_admission(y_applicants, threshold)
            admitted_indices = np.where(a == 1)[0]
            cumulative_X = np.vstack([cumulative_X, X_applicants[admitted_indices]])
            cumulative_y = np.vstack([cumulative_y, y_applicants[admitted_indices]])
            applied_X = np.vstack([cumulative_X, X_applicants])
            percent_admitted_per_stage.append((len(admitted_indices) / len(X_applicants)) * 100)
            stage_utilities.append(np.mean(y_applicants[a == 1]))
            episode_utilities_per_stage.append(stage_utilities)
            model.add_data(cumulative_X, cumulative_y)
            ctgan_model.fit(applied_X)
        else:
            model.select()

            #  Only update if it's time
            if k % update_every == 0:
                X_tensor = torch.tensor(X_applicants, dtype=torch.float32).to(device)

                for iteration in range(max_iter):
                    optimizer.zero_grad()
                    probs = policy_net(X_tensor).clamp(min=1e-6, max=1-1e-6)
                    total_loss = 0
                    total_util = 0

                    for _ in range(n_sample):
                        a = torch.bernoulli(probs).detach().cpu().numpy()
                        X_sample = ctgan_model.sample(300)
                        expected_util = expected_utility(a, X_sample, model, c,
                                                         posterior_sampling=posterior_sampling,
                                                         n_posterior_samples=n_posterior_samples,
                                                         use_selected=use_selected)
                        total_util += expected_util

                        a_tensor = torch.tensor(a, dtype=probs.dtype, device=device)
                        log_probs = a_tensor * torch.log(probs) + (1 - a_tensor) * torch.log(1 - probs)
                        loss = -expected_util * log_probs.mean()
                        total_loss += loss

                    total_loss /= n_sample
                    total_util /= n_sample

                    total_loss.backward()
                    optimizer.step()
                    stage_utilities.append(total_util)

                    if torch.norm(torch.tensor(total_util)) < 1e-4:
                        print(f"Converged at iteration {iteration + 1}")
                        break

            # Apply the (possibly older) policy to applicants
            with torch.no_grad():
                final_probs = policy_net(torch.tensor(X_applicants, dtype=torch.float32).to(device)).cpu().numpy()
                final_actions = np.random.binomial(1, final_probs)

            admitted_indices = np.where(final_actions == 1)[0]
            percent_admitted = (len(admitted_indices) / len(X_applicants)) * 100
            percent_admitted_per_stage.append(percent_admitted)

            applied_X = np.vstack([applied_X, X_applicants])
            valid_indices = admitted_indices[admitted_indices < applied_X.shape[0]]

            if len(valid_indices) > 0:
                cumulative_X = np.vstack([cumulative_X, X_applicants[valid_indices]])
                cumulative_y = np.vstack([cumulative_y, y_applicants[valid_indices]])

            if k >= 1:
                model.add_data(cumulative_X, cumulative_y)
                ctgan_model.fit(applied_X)

            utilities.append(np.mean(y_applicants[valid_indices]) if len(valid_indices) > 0 else 0.0)
            episode_utilities_per_stage.append(stage_utilities)

    return policy_net, utilities, episode_utilities_per_stage, percent_admitted_per_stage




