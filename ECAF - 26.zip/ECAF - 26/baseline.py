from probability_distribution import *
from single_stage_policy_gradient import *

## Threshold
def threshold_selection(X, model, threshold, n_selected):

    predicted_outcomes = model.predict(X, sample=True) 
    average_performance = np.mean(predicted_outcomes, axis=1)
    selected_indices = np.where(average_performance > threshold)[0]
    
    # If there are more than n_selected candidates, randomly select n_selected
    if len(selected_indices) > n_selected:
        selected_indices = np.random.choice(selected_indices, n_selected, replace=False)
    
    return selected_indices

def calculate_threshold_utility(X, model, c, thresholdd, n_selected):
    selected_indices = threshold_selection(X, model, thresholdd, n_selected)
    
    # Create the selection vector 'a' for the selected candidates
    a_vector = np.zeros(X.shape[0])
    a_vector[selected_indices] = 1
    
    # Calculate the expected utility for this subset
    utility_value = expected_utility(a_vector, X, model, c)
    
    return utility_value

#threshold_utility = calculate_threshold_utility(X_test, model, c, threshold=0.80, n_selected=35)


#### gredy

def greedy_selection(X, model, n_selected):
 
    predicted_outcomes = model.predict(X, sample=True)
    total_performance = np.sum(predicted_outcomes, axis=1)
    
    # Select top n based on total performance
    selected_indices = np.argsort(total_performance)[-n_selected:]
    
    return selected_indices

def calculate_greedy_utility(X, model, c, n_selected):
    selected_indices = greedy_selection(X, model, n_selected)
    
    # Create the selection vector 'a' for the selected candidates
    a_vector = np.zeros(X.shape[0])
    a_vector[selected_indices] = 1
    
    # Calculate the expected utility for this subset
    utility_value = expected_utility(a_vector, X, model, c)
    
    return utility_value