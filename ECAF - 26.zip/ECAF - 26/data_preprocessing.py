import pandas as pd
import numpy as np
from sklearn.utils import resample
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
from ctgan import CTGAN
from ctgan.synthesizers import CTGAN
from sklearn.utils import resample
from sklearn.linear_model import LinearRegression, BayesianRidge
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.metrics import accuracy_score
from sklearn.multioutput import MultiOutputRegressor
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
import matplotlib.cm as cm
import torch
from numpy.linalg import inv, cholesky
from scipy.stats import wishart, multivariate_normal

import torch.nn as nn
import torch.optim as optim
from scipy.stats import binom


######## SINGLE STAGE
data = pd.read_csv('admitted_students.csv')
# Create the encoder
categorical_features = ['Gender', 'Citizenship', 'Country of Educational Background']
encoder = OneHotEncoder(drop='first')

# Fit and transform categorical features
encoded_features = pd.get_dummies(data, columns=categorical_features)                                                          
encoded_only = encoded_features.filter(like='_')

# Combine with other features
numeric_features = data.drop(columns=categorical_features + ['Admission Decision', 'Course GPA 1', 
                                                                          'Course GPA 2', 'Course GPA 3'])
scaler = MinMaxScaler()
normalized_numeric_features = scaler.fit_transform(numeric_features)

X = np.hstack([encoded_only, normalized_numeric_features])
y = data[['Course GPA 1', 'Course GPA 2', 'Course GPA 3']].values
y=scaler.fit_transform(y)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)



######## MULTI STAGE
data_g = pd.read_csv('generaed_data.csv')
admitted_students = data_g[data_g['Admission Decision'] == 1]

#  Generate Outcomes y (Course GPAs) for admitted students
np.random.seed(42)
n_admitted = len(admitted_students)

# Compute GPA outcomes based on features of admitted students
course_gpa_1 = admitted_students['High School GPA'] + np.random.normal(0, 0.5, n_admitted) 
course_gpa_2 = admitted_students['Science Points'] * 0.02 + np.random.normal(2, 0.3, n_admitted) 
course_gpa_3 = admitted_students['Language Points'] * 0.05 + np.random.normal(0.5, 0.6, n_admitted) 

# Ensure GPA values are between 0 and 4
course_gpa_1 = np.clip(course_gpa_1, 0, 4)
course_gpa_2 = np.clip(course_gpa_2, 0, 4)
course_gpa_3 = np.clip(course_gpa_3, 0, 4)

# Add to admitted students DataFrame
admitted_students = admitted_students.copy()  # Avoid modifying original DataFrame
admitted_students['Course GPA 1'] = course_gpa_1
admitted_students['Course GPA 2'] = course_gpa_2
admitted_students['Course GPA 3'] = course_gpa_3

# Create the encoder
categorical_features = ['Gender', 'Citizenship', 'Country of Educational Background']
encoder = OneHotEncoder(drop='first')

# Fit and transform categorical features
encoded_features = pd.get_dummies(admitted_students, columns=categorical_features)                                                          
encoded_only = encoded_features.filter(like='_')

# Combine with other features
numeric_features = admitted_students.drop(columns=categorical_features + ['Admission Decision', 
                                'Course GPA 1', 'Course GPA 2', 'Course GPA 3'])
                                                                          

# Normalize numeric features
scaler = MinMaxScaler()
normalized_numeric_features = scaler.fit_transform(numeric_features)

X_s = np.hstack([encoded_only, normalized_numeric_features])
y = admitted_students[['Course GPA 1', 'Course GPA 2', 'Course GPA 3']].values
y_s=scaler.fit_transform(y)


