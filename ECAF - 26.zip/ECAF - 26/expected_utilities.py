import numpy as np
from policies import *
import torch

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

#log linear utility u(a,y)
def utilite(a, y, c, epsilon=1e-7): 
    u_value = 0
    for j in range(3):  #  3 courses
        sum_value = np.sum(a * y[:, j])
        if sum_value <= 0:
            sum_value = epsilon  # Prevent log(0)
        u_value += np.log(sum_value)
    return u_value - c * np.sum(a)

# expected utility U(a,x)   
def expected_utility(a, X, model, c, posterior_sampling=True, n_posterior_samples=10, use_selected=False):
    """
    Computes the expected utility of an action vector `a` for input features `X`
    under model's predictive distribution, using posterior sampling.
    """
    
    if posterior_sampling:
        utilities = []
        for _ in range(n_posterior_samples):
            sampled_outcomes = model.predict(X, sample=True)
            utilities.append(utilite(a, sampled_outcomes, c))
        return np.mean(utilities)
    elif use_selected:
        predicted_outcomes = model.predict(X, sample=False, use_selected=True)
        return utilite(a, predicted_outcomes, c)
    else:
        predicted_outcomes = model.predict(X, sample=False)
        return utilite(a, predicted_outcomes, c)


### NN utility
def policy_utility_nn(X_train, model, c, policy_net,  n_samples, batch_size,posterior_sampling=True, n_posterior_samples=10, use_selected=False):
    """
    Compute average expected utility of the policy over n_samples batches.
    X_train: np.ndarray
    model: outcome prediction model (e.g. Bayesian linear regressor)
    policy_net: PyTorch neural network
    """

    policy_net.eval()
    U_pi_X = 0.0
    
    with torch.no_grad():
        for _ in range(n_samples):
            # Sample batch from population (numpy -> torch)
            x_sample = X_train[np.random.choice(X_train.shape[0], batch_size, replace=True)]
            x_tensor = torch.tensor(x_sample, dtype=torch.float32, device=device)

            # Compute admission probabilities from policy net
            probs = policy_net(x_tensor).cpu().numpy()  # (batch_size,)

            # Sample actions
            a_vector = np.random.binomial(1, probs)
            
            # Compute utility
            U_a_X = expected_utility(a_vector, x_sample, model, c,posterior_sampling=posterior_sampling,
                                     n_posterior_samples=n_posterior_samples,use_selected=use_selected)
            U_pi_X += U_a_X

    return U_pi_X / n_samples

#### Logistic utility
def policy_utility_logistic(X_train, model, c, theta,n_samples, batch_size,posterior_sampling=True, n_posterior_samples=10, use_selected=False):
    U_pi_X = 0
    for _ in range(n_samples):
         # Sample a batch of states x from X_train
        x_sample = X_train[np.random.choice(X_train.shape[0], batch_size, replace=True)]
        
        # Compute policy probabilities for sampled x
        policy_probs = logistic_policy( x_sample, theta)
        a_vector = np.random.binomial(1, policy_probs) # Sample actions a based on the policy probabilities
        
        # Compute utility for the sampled (a, x) pairs
        U_a_X = expected_utility(a_vector, x_sample, model, c,posterior_sampling=posterior_sampling,
                                     n_posterior_samples=n_posterior_samples,use_selected=use_selected)
        U_pi_X += U_a_X

    return U_pi_X / n_samples


