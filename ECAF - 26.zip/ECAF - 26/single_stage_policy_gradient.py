from expected_utilities import *

def policy_gradient(X_population, model, c, learning_rate, delta, max_iter, n_sample, batch_size, device,posterior_sampling=True, 
                    n_posterior_samples=10, use_selected=False,hidden_dim=32):
    """
    Train neural network policy and logistic policy using policy gradient ascent.
    """
    np.random.seed(42)
    theta = np.random.randn(X_population.shape[1]) * 0.01  # Initialize theta
    average_utilities_1=[]

    input_dim = X_population.shape[1]
    policy_net = PolicyNet(input_dim, hidden_dim).to(device)
    optimizer = optim.Adam(policy_net.parameters(), lr=learning_rate)
    average_utilities_2 = []

    for iteration in range(max_iter):

        ##### Logistic part
        grad = np.zeros_like(theta)  # Initialize gradient to zero
        X_batch = X_population[np.random.choice(X_population.shape[0], batch_size, replace=True)] # Sample a batch of states x from X_population
        X_batch = X_batch.detach().cpu().numpy() if isinstance(X_batch, torch.Tensor) else X_batch

        # Compute the policy for the individuals in the batch
        policy = logistic_policy( X_batch, theta)  # Logistic function
        average_util_1 = 0
        policy[policy == 1] = 0.999  # Avoid numerical instability

        ###### NN part
        policy_net.train()
        optimizer.zero_grad()
        x_tensor = torch.tensor(X_batch, dtype=torch.float32, device=device)

        # Forward pass to get admission probabilities
        probs = policy_net(x_tensor)  # (batch_size,)
        probs = probs.clamp(min=1e-6, max=1-1e-6) # To avoid log(0), clamp probabilities
        average_util_2 = 0
        policy_loss = 0  # will accumulate policy gradient loss over n_sample samples

        for k in range(n_sample):

            ##### Logistic part
            X_batch = X_batch.detach().cpu().numpy() if isinstance(X_batch, torch.Tensor) else X_batch
            a = np.random.binomial(1, policy)  # Sample actions for individuals in the batch
            expected_util = expected_utility(a, X_batch, model, c,posterior_sampling=posterior_sampling,
                                     n_posterior_samples=n_posterior_samples,use_selected=use_selected)
            average_util_1 += expected_util

            for i in range(X_batch.shape[0]):  # i: individual
                # Compute the gradient contribution for the i-th individual
                if a[i] == 1:
                    grad_c = X_batch[i] * (1 - policy[i])
                else:
                    grad_c = -X_batch[i] * policy[i]

                # Scale gradient by the difference between action and policy
                grad += (expected_util * grad_c) / n_sample

            ####### NN part
            # Sample actions from Bernoulli with probs
            a_n = torch.bernoulli(probs).detach().cpu().numpy()
            
            # Compute utility of these actions
            U_a_X = expected_utility(a_n, X_batch, model, c, posterior_sampling=posterior_sampling,
                                     n_posterior_samples=n_posterior_samples,use_selected=use_selected)
            average_util_2 += U_a_X

            # Compute log-probabilities for sampled actions
            a_n = torch.tensor(a_n, dtype=probs.dtype, device=device)
            log_probs = a_n * torch.log(probs) + (1 - a_n) * torch.log(1 - probs)  # (batch_size,)

            # Policy gradient objective: maximize expected utility
            # So loss = -U * sum log_probs
            loss = -U_a_X * log_probs.mean()  # mean over batch for stable gradient

            policy_loss += loss

        # Update theta using gradient ascent
        theta_new = theta + learning_rate * grad
        if np.linalg.norm(theta_new - theta) < delta:    # Check for convergence
            print(f"Converged at iteration {iteration}")
            break

        average_util_1 /= n_sample
        average_utilities_1.append(average_util_1)  # Store the average utility
        theta = theta_new  # Update theta for the next iteration

        policy_loss /= n_sample
        average_util_2 /= n_sample
        average_utilities_2.append(average_util_2)

        # Backprop and optimizer step
        policy_loss.backward()
        optimizer.step()

        # Check convergence (optional)
        if iteration > 0 and abs(average_utilities_2[-1] - average_utilities_2[-2]) < delta:
            print(f"Converged at iteration {iteration}")
            break

        #if iteration % 10 == 0 or iteration == max_iter - 1:
            #print(f"Iter {iteration}: Avg Utility = {average_util:.4f}")

    return policy_net, theta, average_utilities_1, average_utilities_2
