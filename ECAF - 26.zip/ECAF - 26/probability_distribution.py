from numpy.linalg import inv, cholesky
from scipy.stats import wishart, multivariate_normal
import numpy as np
from scipy.stats import binom

#### This implementation follow the Thomas P. Minka paper "Bayesian Linear
##### Regression", Technical Report, February 20, 2001.

class BayesianMultivariateLinearRegression:
    def __init__(self, m, d, S0=None, N0=None, a=1.0, ThompsonSampling=False):
        """
        m: input dimension
        d: output dimension
        S0: prior scale matrix (d x d)
        N0: prior degrees of freedom
        a: prior scaling for input precision
        ThompsonSampling: whether to enable Thompson sampling
        """
        self.m = m
        self.d = d
        self.a = a
        self.ThompsonSampling = ThompsonSampling

        self.N = 0  # number of observations
        self.N0 = N0 if N0 is not None else d
        self.S0 = S0 if S0 is not None else np.eye(d)

        self.K = a * np.eye(m)  # Prior precision for X
        self.M = np.zeros((d, m))  # Posterior mean
        self.A = np.copy(self.M)   # Sampled matrix for Thompson sampling

        self.Sxx = np.copy(self.K)
        self.Syx = self.M @ self.K
        self.Syy = self.Syx @ self.M.T
        self.inv_Sxx = inv(self.Sxx)
        self.Sy_x = self.Syy - self.M @ self.Syx.T  # For predictive
        self.V = np.eye(d)

    def add_data(self, X, Y):
        """
        X: (n x m) matrix
        Y: (n x d) matrix
        """
        for x, y in zip(X, Y):
            x = x.reshape(-1, 1)  # (m x 1)
            y = y.reshape(-1, 1)  # (d x 1)
            self.N += 1
            self.Sxx += x @ x.T
            self.Syx += y @ x.T
            self.Syy += y @ y.T

        self.inv_Sxx = inv(self.Sxx)
        self.M = self.Syx @ self.inv_Sxx
        self.Sy_x = self.Syy - self.M @ self.Syx.T

    def sample_posterior(self):
        """
        Samples (M, V) from posterior:
        - V ~ Inv-Wishart(N0 + N, S0 + Sy_x)
        - M ~ Matrix Normal(M, V, Sxx^{-1})
        """
        V = inv(wishart.rvs(df=self.N + self.N0, scale=inv(self.S0 + self.Sy_x)))
        chol_V = cholesky(V)
        chol_K = cholesky(self.inv_Sxx)
        Z = np.random.randn(self.d, self.m)
        M_sample = self.M + chol_V @ Z @ chol_K.T
        return M_sample, V

    def generate(self):
        """
        Generates a new sample A from the posterior.
        """
        M_sample, V = self.sample_posterior()
        self.V = V
        return M_sample

    def select(self):
        """
        Thompson Sampling step: choose A based on sampled posterior or mean.
        """
        if self.ThompsonSampling:
            self.A = self.generate()
        else:
            self.A = self.M

    def predict(self, X, sample=False, use_selected=False):
        """
        Predict y given X.
        If sample=True, sample from posterior predictive.
        If use_selected=True, use matrix A instead of M.
        """
        X = np.atleast_2d(X)

        if sample:
            M, V = self.sample_posterior()
        elif use_selected:
            M = self.A
            V = self.V
        else:
            M = self.M
            V = self.Sy_x / (self.N + self.N0 - self.d - 1)

        preds = []
        for x in X:
            x = x.reshape(-1, 1)
            mean = (M @ x).flatten()
            cov = (1 + x.T @ self.inv_Sxx @ x).item() * V
            if sample:
                y = multivariate_normal.rvs(mean=mean, cov=cov)
            else:
                y = mean
            preds.append(y)

        return np.array(preds)

    def logpdf(self, x, y):
        """
        Evaluate log density of y given x under posterior predictive Student-t
        """
        from scipy.stats import multivariate_t
        nu = self.N + self.N0 - self.d + 1
        mean = self.M @ x
        scale = (1 + x.T @ self.inv_Sxx @ x).item() * self.Sy_x / nu
        return multivariate_t.logpdf(y, df=nu, loc=mean, shape=scale)

    def reset(self):
        self.N = 0
        self.M = np.zeros((self.d, self.m))
        self.A = np.zeros((self.d, self.m))
        self.Sxx = np.copy(self.K)
        self.Syx = np.zeros((self.d, self.m))
        self.Syy = np.zeros((self.d, self.d))
        self.inv_Sxx = inv(self.Sxx)
        self.Sy_x = self.Syy - self.M @ self.Syx.T




