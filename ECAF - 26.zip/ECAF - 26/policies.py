import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

class PolicyNet(nn.Module):
    def __init__(self, input_dim, hidden_dim=64, dropout=0.2):
        super(PolicyNet, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()  # Output is admission probability
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)  # Shape: (batch_size,)
    
def logistic_policy( X, theta):
    dot_products = np.dot(X, theta)
    policy_probs = np.exp( dot_products) / (1 + np.exp( dot_products))
    return policy_probs